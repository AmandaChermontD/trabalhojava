package com.projeto.senac.exceptions;

public class CriptoExistsExpetion extends Exception {
	private static final long serialVersionUID = 1L;
	
	public CriptoExistsExpetion(String msg) {
		super(msg);
		
	}

}
