package com.projeto.amandalopes.model;

public class Contato {

}
